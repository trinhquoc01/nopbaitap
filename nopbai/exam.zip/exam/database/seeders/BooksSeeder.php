<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class BooksSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('books')->insert([
            'authorid' => '1',
            'title' => 'To Kill a Mockingbird ',
            'ISBN' => '978-0-06-112008-4',
            'pub_year' => 2001,
            'available'=>'yes'
        ]);
        DB::table('books')->insert([
            'authorid' => '2',
            'title' => 'Pride and Prejudice ',
            'ISBN' => '978-0-452-28423-4',
            'pub_year' => 1800,
            'available'=>'yes'
        ]);
        DB::table('books')->insert([
            'authorid' => '3',
            'title' => 'The Great Gatsby   ',
            'ISBN' => '978-0-19-953556-9',
            'pub_year' => 1960,
            'available'=>'yes'
        ]);
        DB::table('books')->insert([
            'authorid' => '4',
            'title' => 'Harry Potter  ',
            'ISBN' => '978-0-7432-7356-5',
            'pub_year' => 1980,
            'available'=>'yes'
        ]);
        DB::table('books')->insert([
            'authorid' => '5',
            'title' => 'The Catcher in the Rye ',
            'ISBN' => '978-0-316-76948-0 ',
            'pub_year' => 1987,
            'available'=>'yes'
        ]);
        DB::table('books')->insert([
            'authorid' => '6',
            'title' => 'The Fellowship of the Ring ',
            'ISBN' => ' 978-0-395-07122-6 ',
            'pub_year' => 1539,
            'available'=>'yes'
        ]);
        DB::table('books')->insert([
            'authorid' => '7',
            'title' => 'The Hobbit  ',
            'ISBN' => '978-0-06-085052-4 ',
            'pub_year' => 1745,
            'available'=>'yes'
        ]);
        DB::table('books')->insert([
            'authorid' => '8',
            'title' => 'Brave New World    ',
            'ISBN' => '978-0-7679-2767-0',
            'pub_year' => 1932,
            'available'=>'yes'
        ]);
        DB::table('books')->insert([
            'authorid' => '9',
            'title' => 'the Ring ',
            'ISBN' => '978-0-03-112308-4',
            'pub_year' => 1961,
            'available'=>'yes'
        ]);
        DB::table('books')->insert([
            'authorid' => '10',
            'title' => 'The Da Vinci Code  ',
            'ISBN' => '938-0-06-112008-1',
            'pub_year' => 2000,
            'available'=>'yes'
        ]);
    }
}
