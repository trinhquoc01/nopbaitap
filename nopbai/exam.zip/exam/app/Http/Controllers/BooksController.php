<?php

namespace App\Http\Controllers;

use App\Models\Book;
use Illuminate\Http\Request;

class BooksController extends Controller
{
    public function index()
    {
        $data = Book::latest()->paginate(10);

        return view('index', compact('data'));
    }



    public function searchBooks(Request $request)
    {
        $query = $request->input('query');

        $books = Book::where('title', 'like', "%$query%")->get();

        return view('books', compact('books', 'query'));
    }
}
